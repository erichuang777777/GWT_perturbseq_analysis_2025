#!/usr/bin/env Rscript
# STAGE 03 reproducibility: recompute processed matrices from raw DE stats (R).
#
# Independently pivots the curated DE supplementary table into two
# target x condition matrices (effect_matrix from ontarget_effect_size,
# de_matrix from n_total_de_genes), without reference to the Python
# implementation or the existing artifacts.

suppressMessages(library(tidyverse))

args <- commandArgs(trailingOnly = TRUE)
raw <- if (length(args) >= 1) args[1] else "raw.csv"

df <- readr::read_csv(raw, show_col_types = FALSE)

idx <- "target_contrast_gene_name"
col <- "culture_condition"

# Guard: (target, condition) must be unique for a well-defined pivot.
dups <- df %>% count(.data[[idx]], .data[[col]]) %>% filter(n > 1) %>% nrow()
stopifnot(dups == 0)

pivot_mat <- function(value_col) {
  df %>%
    select(all_of(c(idx, col, value_col))) %>%
    pivot_wider(names_from = all_of(col), values_from = all_of(value_col)) %>%
    arrange(.data[[idx]])
}

effect <- pivot_mat("ontarget_effect_size")
de <- pivot_mat("n_total_de_genes")

# Canonical column ordering: index first, then conditions alphabetically.
order_cols <- function(m) {
  conds <- sort(setdiff(colnames(m), idx))
  m[, c(idx, conds)]
}
effect <- order_cols(effect)
de <- order_cols(de)

readr::write_csv(effect, "effect_r.csv")
readr::write_csv(de, "de_r.csv")

cat(sprintf("effect shape (incl index) = %dx%d\n", nrow(effect), ncol(effect)))
cat(sprintf("de shape (incl index)     = %dx%d\n", nrow(de), ncol(de)))
