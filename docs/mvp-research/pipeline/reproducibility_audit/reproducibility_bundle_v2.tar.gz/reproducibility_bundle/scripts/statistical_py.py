#!/usr/bin/env python3
"""
STAGE 04 reproducibility: independent Python recompute of the CD4+ T-cell
Perturb-seq DE summary statistics, straight from the raw suppl_table CSV.

Usage:  python stats_recompute_py.py <raw_csv> <out_json>
Output: JSON dict {metric: value} written to <out_json>.

No dependency on the existing summary_statistics artifact — every value is
recomputed from the raw table so this can serve as an independent check
against the R recompute (stats_recompute_r.R).
"""
import sys, json
import numpy as np
import pandas as pd


def compute(raw_csv: str) -> dict:
    df = pd.read_csv(raw_csv)

    # Boolean columns arrive as True/False strings or python bools; normalise.
    def as_bool(s):
        if s.dtype == bool:
            return s.fillna(False)
        return s.astype(str).str.strip().str.lower().isin(["true", "1"]).fillna(False)

    sig = as_bool(df["ontarget_significant"])
    off = as_bool(df["offtarget_flag"])
    ncells = df["n_cells_target"]
    nde = df["n_total_de_genes"]

    # Gate: n_cells>=200 & significant & !offtarget & n_total_de_genes>=50, NA->FALSE
    gate = (
        (ncells >= 200).fillna(False)
        & sig
        & (~off)
        & (nde >= 50).fillna(False)
    )

    m = {}
    m["n_rows"] = int(len(df))
    m["n_unique_targets"] = int(df["target_contrast"].nunique())
    m["n_ontarget_significant"] = int(sig.sum())
    m["n_offtarget_flag"] = int(off.sum())
    m["n_gate_passing_rows"] = int(gate.sum())
    m["n_gate_passing_unique_targets"] = int(df.loc[gate, "target_contrast"].nunique())
    m["count_Rest"] = int((df["culture_condition"] == "Rest").sum())
    m["count_Stim8hr"] = int((df["culture_condition"] == "Stim8hr").sum())
    m["count_Stim48hr"] = int((df["culture_condition"] == "Stim48hr").sum())
    m["nde_median"] = float(np.median(nde))
    m["nde_max"] = float(nde.max())
    m["effect_min"] = float(df["ontarget_effect_size"].min())
    m["effect_median"] = float(df["ontarget_effect_size"].median())
    m["effect_max"] = float(df["ontarget_effect_size"].max())
    m["ncells_median"] = float(np.median(ncells))
    m["corr_nde_ndownstream"] = float(np.corrcoef(nde, df["n_downstream"])[0, 1])
    m["frac_logde_lt1"] = float((np.log10(nde + 1) < 1).mean())
    m["set_significant_genelevel"] = int(df.loc[sig, "target_contrast_gene_name"].nunique())

    return m


def compute_extended(raw_csv):
    # Optional extension, NOT part of the audited 18-metric summary_statistics artifact.
    # Per-condition up/down DE gene sums, kept separate so the core output reproduces
    # summary_statistics.csv byte-for-byte under canonicalisation.
    df = pd.read_csv(raw_csv)
    ext = {}
    for cond in ["Rest", "Stim8hr", "Stim48hr"]:
        sub = df[df["culture_condition"] == cond]
        ext[f"sum_up_{cond}"] = int(sub["n_up_genes"].sum())
        ext[f"sum_down_{cond}"] = int(sub["n_down_genes"].sum())
    return ext


if __name__ == "__main__":
    raw_csv, out_json = sys.argv[1], sys.argv[2]
    # Core 18-metric summary_statistics (the audited artifact).
    res = compute(raw_csv)
    with open(out_json, "w") as fh:
        json.dump(res, fh, indent=2)
    print(json.dumps(res, indent=2))
    # Extended metrics written alongside (optional; not checksum-audited).
    ext_json = out_json.replace(".json", "_extended.json")
    with open(ext_json, "w") as fh:
        json.dump(compute_extended(raw_csv), fh, indent=2)
