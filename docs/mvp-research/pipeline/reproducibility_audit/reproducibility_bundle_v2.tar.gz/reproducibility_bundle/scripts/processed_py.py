#!/usr/bin/env python3
"""STAGE 03 reproducibility: recompute processed matrices from raw DE stats (Python).

Independently pivots the curated DE supplementary table into two target x condition
matrices (effect_matrix from ontarget_effect_size, de_matrix from n_total_de_genes),
without reference to the R implementation or the existing artifacts.
"""
import sys
import pandas as pd

RAW = sys.argv[1] if len(sys.argv) > 1 else "raw.csv"

def main():
    df = pd.read_csv(RAW)
    idx, col = "target_contrast_gene_name", "culture_condition"

    # Guard: a (target, condition) pair must be unique for a well-defined pivot.
    dups = df.duplicated([idx, col]).sum()
    assert dups == 0, f"{dups} duplicate (target,condition) pairs -> pivot ambiguous"

    effect = df.pivot(index=idx, columns=col, values="ontarget_effect_size")
    de = df.pivot(index=idx, columns=col, values="n_total_de_genes")

    # Canonical ordering: sort rows by target, columns alphabetically.
    effect = effect.sort_index().reindex(sorted(effect.columns), axis=1)
    de = de.sort_index().reindex(sorted(de.columns), axis=1)

    effect.to_csv("effect_py.csv")
    de.to_csv("de_py.csv")
    print(f"effect shape (incl index) = {effect.shape[0]}x{effect.shape[1]+1}")
    print(f"de shape (incl index)     = {de.shape[0]}x{de.shape[1]+1}")

if __name__ == "__main__":
    main()
