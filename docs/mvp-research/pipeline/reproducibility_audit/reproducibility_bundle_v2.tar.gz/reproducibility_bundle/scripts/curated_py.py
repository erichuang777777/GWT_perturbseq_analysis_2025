#!/usr/bin/env python3
"""
STAGE 01 -> 02 curation recompute (Python, INDEPENDENT reimplementation).

Reproducibility-audit artifact. Reads the RAW DE_stats supplementary table and
recomputes the curated / gate-passing stage output from scratch, with no
dependency on the existing curated artifact.

Per-column calc logic
----------------------
- passes_gate : boolean gate on each target x condition row.
      passes_gate = (n_cells_target      >= 200)
                AND (ontarget_significant == True)
                AND (offtarget_flag       == False)
                AND (n_total_de_genes     >= 50)
      Any NA in an input term makes that term False (NA-safe AND); an otherwise-True
      row with an NA term therefore fails the gate.
- logDE : log10(n_total_de_genes + 1). Compression of the DE-gene count for plotting.
- All 16 original columns are carried through unchanged (standardised order).

Outputs (written into --outdir)
-------------------------------
- curated_py.csv         : full annotated table = raw + passes_gate + logDE (33,983 rows)
- gate_passing_py.csv    : subset where passes_gate is True (2,131 rows)
- curated_targets_py.csv : gate-passing set deduplicated to unique targets (1,235 rows)
"""
import argparse, os
import numpy as np
import pandas as pd

DEFAULT_RAW = "/Users/eric777/.claude-science/orgs/da569c35-fbb9-41f8-ad57-1225ad245b87/artifacts/proj_9efc9e969acb/eb4c9b7d-b197-47c5-824c-efbd6bc2b805/v11c6348b_DE_stats.suppl_table.csv"

ORIG_COLS = ["index","target_contrast_gene_name","culture_condition","target_contrast",
             "chunk","n_cells_target","n_up_genes","n_down_genes","n_total_de_genes",
             "ontarget_effect_size","ontarget_significant","target_baseMean","offtarget_flag",
             "n_total_genes_category","ontarget_effect_category","n_downstream"]

def recompute(raw: pd.DataFrame) -> pd.DataFrame:
    df = raw.copy()
    # NA-safe boolean terms
    t_cells = (df["n_cells_target"]       >= 200)
    t_sig   = (df["ontarget_significant"] == True)
    t_off   = (df["offtarget_flag"]       == False)
    t_de    = (df["n_total_de_genes"]     >= 50)
    passes = (t_cells & t_sig & t_off & t_de)
    df["passes_gate"] = passes.fillna(False).astype(bool)
    df["logDE"] = np.log10(df["n_total_de_genes"] + 1)
    return df

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", default=DEFAULT_RAW)
    ap.add_argument("--outdir", default=".")
    a = ap.parse_args()
    os.makedirs(a.outdir, exist_ok=True)

    raw = pd.read_csv(a.raw)
    curated = recompute(raw)

    out_cols = ORIG_COLS + ["passes_gate", "logDE"]
    curated = curated[out_cols]
    gate_passing = curated[curated["passes_gate"]].copy()
    curated_targets = gate_passing.drop_duplicates(subset=["target_contrast"]).copy()

    curated.to_csv(os.path.join(a.outdir, "curated_py.csv"), index=False)
    gate_passing.to_csv(os.path.join(a.outdir, "gate_passing_py.csv"), index=False)
    curated_targets.to_csv(os.path.join(a.outdir, "curated_targets_py.csv"), index=False)

    print(f"rows={len(curated)} passes_gate={int(curated['passes_gate'].sum())} "
          f"unique_targets={curated_targets['target_contrast'].nunique()}")

if __name__ == "__main__":
    main()
