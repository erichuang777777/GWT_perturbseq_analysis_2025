#!/usr/bin/env Rscript
# STAGE 01 -> 02 curation recompute (R, INDEPENDENT reimplementation).
#
# Reproducibility-audit artifact. Reads the RAW DE_stats supplementary table and
# recomputes the curated / gate-passing stage output from scratch, with no
# dependency on the existing curated artifact and no shared code with the Python
# implementation.
#
# Per-column calc logic
# ----------------------
# - passes_gate : boolean gate on each target x condition row.
#       passes_gate = (n_cells_target      >= 200)
#                 AND (ontarget_significant == TRUE)
#                 AND (offtarget_flag       == FALSE)
#                 AND (n_total_de_genes     >= 50)
#       Any NA in an input term makes that term FALSE (NA-safe AND); an otherwise-TRUE
#       row with an NA term therefore fails the gate.
# - logDE : log10(n_total_de_genes + 1). Compression of the DE-gene count for plotting.
# - All 16 original columns are carried through unchanged (standardised order).
#
# Outputs (written into --outdir)
# -------------------------------
# - curated_r.csv          : full annotated table = raw + passes_gate + logDE (33,983 rows)
# - gate_passing_r.csv     : subset where passes_gate is TRUE (2,131 rows)
# - curated_targets_r.csv  : gate-passing set deduplicated to unique targets (1,235 rows)

suppressMessages({
  library(readr)
  library(dplyr)
})

DEFAULT_RAW <- "/Users/eric777/.claude-science/orgs/da569c35-fbb9-41f8-ad57-1225ad245b87/artifacts/proj_9efc9e969acb/eb4c9b7d-b197-47c5-824c-efbd6bc2b805/v11c6348b_DE_stats.suppl_table.csv"

ORIG_COLS <- c("index","target_contrast_gene_name","culture_condition","target_contrast",
               "chunk","n_cells_target","n_up_genes","n_down_genes","n_total_de_genes",
               "ontarget_effect_size","ontarget_significant","target_baseMean","offtarget_flag",
               "n_total_genes_category","ontarget_effect_category","n_downstream")

args <- commandArgs(trailingOnly = TRUE)
get_arg <- function(flag, default) {
  i <- which(args == flag)
  if (length(i) == 1 && i < length(args)) args[i + 1] else default
}
raw_path <- get_arg("--raw", DEFAULT_RAW)
outdir   <- get_arg("--outdir", ".")
dir.create(outdir, showWarnings = FALSE, recursive = TRUE)

# Read with explicit logical parsing so "True"/"False" become TRUE/FALSE/NA.
raw <- readr::read_csv(
  raw_path,
  col_types = cols(
    ontarget_significant = col_logical(),
    offtarget_flag       = col_logical(),
    .default = col_guess()
  ),
  na = c("", "NA")
)

na_false <- function(x) ifelse(is.na(x), FALSE, x)

passes <- na_false(raw$n_cells_target       >= 200) &
          na_false(raw$ontarget_significant == TRUE) &
          na_false(raw$offtarget_flag       == FALSE) &
          na_false(raw$n_total_de_genes     >= 50)

curated <- raw
curated$passes_gate <- as.logical(passes)
curated$logDE       <- log10(raw$n_total_de_genes + 1)
curated <- curated[, c(ORIG_COLS, "passes_gate", "logDE")]

gate_passing    <- curated[curated$passes_gate, , drop = FALSE]
curated_targets <- gate_passing[!duplicated(gate_passing$target_contrast), , drop = FALSE]

readr::write_csv(curated,         file.path(outdir, "curated_r.csv"))
readr::write_csv(gate_passing,    file.path(outdir, "gate_passing_r.csv"))
readr::write_csv(curated_targets, file.path(outdir, "curated_targets_r.csv"))

cat(sprintf("rows=%d passes_gate=%d unique_targets=%d\n",
            nrow(curated), sum(curated$passes_gate),
            length(unique(curated_targets$target_contrast))))
