#!/usr/bin/env Rscript
# STAGE 04 reproducibility: independent R recompute of the CD4+ T-cell
# Perturb-seq DE summary statistics, straight from the raw suppl_table CSV.
#
# Usage:  Rscript stats_recompute_r.R <raw_csv> <out_json>
# Output: JSON dict {metric: value} written to <out_json>.
#
# No dependency on the existing summary_statistics artifact — every value is
# recomputed from the raw table so this can serve as an independent check
# against the Python recompute (stats_recompute_py.py).

suppressMessages({
  library(readr)
  library(dplyr)
  library(jsonlite)
})

args <- commandArgs(trailingOnly = TRUE)
raw_csv <- args[1]
out_json <- args[2]

de <- read_csv(raw_csv, show_col_types = FALSE)

# Normalise logical columns (read as logical by readr, but be defensive).
to_bool <- function(x) {
  if (is.logical(x)) return(ifelse(is.na(x), FALSE, x))
  v <- tolower(trimws(as.character(x)))
  res <- v %in% c("true", "1")
  ifelse(is.na(res), FALSE, res)
}

sig <- to_bool(de$ontarget_significant)
off <- to_bool(de$offtarget_flag)
ncells <- de$n_cells_target
nde <- de$n_total_de_genes

# Gate: n_cells>=200 & significant & !offtarget & n_total_de_genes>=50, NA->FALSE
gate <- (ncells >= 200) & sig & (!off) & (nde >= 50)
gate[is.na(gate)] <- FALSE

m <- list()
m$n_rows <- nrow(de)
m$n_unique_targets <- n_distinct(de$target_contrast)
m$n_ontarget_significant <- sum(sig)
m$n_offtarget_flag <- sum(off)
m$n_gate_passing_rows <- sum(gate)
m$n_gate_passing_unique_targets <- n_distinct(de$target_contrast[gate])
m$count_Rest <- sum(de$culture_condition == "Rest")
m$count_Stim8hr <- sum(de$culture_condition == "Stim8hr")
m$count_Stim48hr <- sum(de$culture_condition == "Stim48hr")
m$nde_median <- median(nde)
m$nde_max <- max(nde)
m$effect_min <- min(de$ontarget_effect_size, na.rm = TRUE)
m$effect_median <- median(de$ontarget_effect_size, na.rm = TRUE)
m$effect_max <- max(de$ontarget_effect_size, na.rm = TRUE)
m$ncells_median <- median(ncells)
m$corr_nde_ndownstream <- cor(nde, de$n_downstream, method = "pearson")
m$frac_logde_lt1 <- mean(log10(nde + 1) < 1)
m$set_significant_genelevel <- n_distinct(de$target_contrast_gene_name[sig])

# unbox so scalars serialise as JSON numbers, not length-1 arrays.
m <- lapply(m, function(x) unbox(as.numeric(x)))
write_json(m, out_json, pretty = TRUE, digits = 15)
cat(toJSON(m, pretty = TRUE, digits = 15), "\n")

# Optional extension, NOT part of the audited 18-metric summary_statistics artifact.
# Written to a separate file so the core output reproduces summary_statistics.csv.
ext <- list()
for (cond in c("Rest", "Stim8hr", "Stim48hr")) {
  sub <- de[de$culture_condition == cond, ]
  ext[[paste0("sum_up_", cond)]] <- sum(sub$n_up_genes)
  ext[[paste0("sum_down_", cond)]] <- sum(sub$n_down_genes)
}
ext <- lapply(ext, function(x) unbox(as.numeric(x)))
write_json(ext, sub(".json$", "_extended.json", out_json), pretty = TRUE, digits = 15)
