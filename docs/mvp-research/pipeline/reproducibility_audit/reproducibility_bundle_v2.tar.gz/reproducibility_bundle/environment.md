# Environment specification

This bundle was audited/produced under the following runtimes. Reproduce with
matching major/minor versions; patch-level differences are usually harmless for
the tabular outputs but the canonical-checksum (see REPRODUCE.md) is the
authority when float serialization differs.

## Python
- python 3.11.15
- pandas 2.3.3
- numpy 2.4.6
- scipy 1.17.1

Recreate:
```
conda create -n perturbseq-py python=3.11.15
conda activate perturbseq-py
pip install "pandas==2.3.3" "numpy==2.4.6" "scipy==1.17.1"
```

## R
- R 4.5.3
- tidyverse 2.0.0 (dplyr 1.2.1, readr 2.2.0, tibble 3.3.1)
- jsonlite 2.0.0

Recreate:
```
conda create -n perturbseq-r -c conda-forge r-base=4.5.3 r-tidyverse=2.0.0 r-jsonlite=2.0.0
conda activate perturbseq-r
```

## Notes
- scipy is listed for completeness; the DE-statistics were precomputed upstream
  and supplied as the raw table, so the reproduction scripts here rely mainly on
  pandas/numpy (Python) and dplyr/readr (R).
- Package versions above are those detected in the audit environment.
