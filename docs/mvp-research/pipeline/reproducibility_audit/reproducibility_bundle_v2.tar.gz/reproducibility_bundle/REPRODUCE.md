# REPRODUCE.md — CD4+ T-cell Perturb-seq pipeline

Self-contained reproduction from raw data alone. An outside party needs only
`raw/DE_stats.suppl_table.csv` (shipped in this bundle) plus the environments in
`environment.md`.

## Bundle layout
```
reproducibility_bundle/
  raw/DE_stats.suppl_table.csv        # sole raw input (precomputed DE statistics)
  scripts/
    curated_py.py      curated_r.R       # stage 1: gate annotation
    processed_py.py    processed_r.R     # stage 2: effect_matrix / de_matrix
    statistical_py.py  statistical_r.R   # stage 3: summary_statistics
  expected_outputs_checksums.csv        # canonical md5 per stage output
  environment.md
  REPRODUCE.md
```

Each stage reads the **raw** table directly (the stages are independent
re-derivations from raw, not a chained hand-off). Run either the Python or the R
implementation of a stage — they are intended to produce equivalent tables.

Set a working path to the raw file:
```
RAW=raw/DE_stats.suppl_table.csv
```

## Stage 1 — curated / gate-passing
Python:
```
python scripts/curated_py.py --raw "$RAW" --outdir out
# -> out/curated_py.csv (33,983 rows), out/gate_passing_py.csv (2,131 rows),
#    out/curated_targets_py.csv
```
R:
```
Rscript scripts/curated_r.R --raw "$RAW" --outdir out
# -> out/curated_r.csv, out/gate_passing_r.csv, out/curated_targets_r.csv
```
Maps to expected outputs: `curated_targets` and `gate_passing_targets`
(the full annotated 33,983-row table is `curated_targets`; the passes_gate==True
subset of 2,131 rows is `gate_passing_targets`).

> **DECOY WARNING — do not match by filename.** `curated_py.py`/`curated_r.R`
> write a THIRD file literally named `curated_targets_py.csv` /
> `curated_targets_r.csv` (gate-passing set deduplicated to unique targets,
> ~1,235 rows). This is NOT the `curated_targets` expected output. The
> `curated_targets` checksum corresponds to the FULL 33,983-row annotated table,
> i.e. `curated_py.csv` / `curated_r.csv`. Checksum `curated_py.csv` (33,983
> rows) against `curated_targets`, and `gate_passing_py.csv` (2,131 rows) against
> `gate_passing_targets`. The 1,235-row `curated_targets_*.csv` has no expected
> checksum in this bundle — ignore it for verification.

## Stage 2 — processed matrices
Python:
```
python scripts/processed_py.py "$RAW"
# -> effect_py.csv, de_py.csv
```
R:
```
Rscript scripts/processed_r.R "$RAW"
# -> effect_r.csv, de_r.csv
```
Maps to expected outputs: `effect_matrix` and `de_matrix`
(target x {Rest, Stim8hr, Stim48hr}, 11,526 rows).

## Stage 3 — summary statistics
Python:
```
python scripts/statistical_py.py "$RAW" summary_py.json
```
R:
```
Rscript scripts/statistical_r.R "$RAW" summary_r.json
```
Maps to expected output: `summary_statistics`. The scripts emit a JSON object of
metric->value pairs; the canonical `summary_statistics` artifact is the same
metrics tabulated into two columns, `metric` and `value` (18 rows). To compare,
flatten the JSON into that two-column form before checksumming.

## Verifying against expected_outputs_checksums.csv

`expected_outputs_checksums.csv` records, per stage output, a **canonical md5**.
Byte-for-byte md5 of a freshly written CSV will generally NOT match between R and
Python (and even between pandas versions) because of float formatting, column
order, NA rendering, and row order. The canonical md5 removes those differences.

### Canonicalisation (the authority)
Given a stage output table, compute its canonical bytes as follows, then md5 them:
1. **Columns** reordered alphabetically (ascending, case-sensitive).
2. **Rows** sorted ascending by the key column first, then by all remaining
   (already alphabetised) columns as tie-breakers, using a stable sort.
   Key columns: `curated_targets`->`index`, `gate_passing_targets`->`index`,
   `effect_matrix`->`target_contrast_gene_name`,
   `de_matrix`->`target_contrast_gene_name`, `summary_statistics`->`metric`.
3. **Cell formatting** (string-normalise every value so R/Python serialization
   differences vanish):
   - missing/NaN -> empty string `""`
   - booleans -> `"True"` / `"False"`
   - integers -> plain decimal, no `.0`
   - floats -> Python `format(x, ".10g")` (10 significant digits, general format)
   - everything else -> its string form
4. Write the normalised table to CSV with `,` separator, **no index column**,
   header row kept, and `"\n"` line terminator; encode UTF-8.
5. `md5` of those bytes = the canonical md5 to compare against the CSV.

### Reference implementation (Python)
```python
import pandas as pd, numpy as np, hashlib, io

KEYS = {"curated_targets":"index","gate_passing_targets":"index",
        "effect_matrix":"target_contrast_gene_name",
        "de_matrix":"target_contrast_gene_name","summary_statistics":"metric"}

def canonical_md5(df, key):
    df = df[sorted(df.columns)]
    sort_cols = [key] + [c for c in df.columns if c != key]
    df = df.sort_values(sort_cols, kind="mergesort").reset_index(drop=True)
    def fmt(v):
        if pd.isna(v): return ""
        if isinstance(v,(bool,np.bool_)): return "True" if v else "False"
        if isinstance(v,(int,np.integer)): return str(int(v))
        if isinstance(v,(float,np.floating)): return format(float(v), ".10g")
        return str(v)
    buf = io.StringIO(); df.map(fmt).to_csv(buf, index=False, lineterminator="\n")
    return hashlib.md5(buf.getvalue().encode("utf-8")).hexdigest()

exp = pd.read_csv("expected_outputs_checksums.csv").set_index("stage_output")["canonical_md5"]
got = canonical_md5(pd.read_csv("out/curated_py.csv"), KEYS["curated_targets"])
assert got == exp["curated_targets"], (got, exp["curated_targets"])
```
Apply the same function to each stage output (loading the JSON->metric/value form
for `summary_statistics`) and compare to the corresponding row of
`expected_outputs_checksums.csv`.

> Note: byte-level md5 may differ between R and Python due to float
> serialization; the **canonical-checksum is the authority**.


## Note on statistical stage
The statistical scripts write the audited 18-metric `summary_statistics` (the checksum-verified artifact) to the main output, and 6 optional per-condition DE-gene sums to a separate `*_extended.json`. Only the 18-metric core output is checksum-audited.
